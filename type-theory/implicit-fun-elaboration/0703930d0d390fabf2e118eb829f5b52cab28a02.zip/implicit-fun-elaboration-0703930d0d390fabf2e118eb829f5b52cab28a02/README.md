
Sources and implementation of the ICFP 2020 paper "Elaboration with First-Class Implicit Function Types" by András Kovács. 

[Paper](paper.pdf), [implementation](fcif).
